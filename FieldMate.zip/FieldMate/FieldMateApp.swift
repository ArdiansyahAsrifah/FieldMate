//
//  FieldMateApp.swift
//  FieldMate
//
//  Created by Muhammad Ardiansyah Asrifah on 20/03/25.
//

import SwiftUI

@main
struct FieldMateApp: App {
    var body: some Scene {
        WindowGroup {
            ScheduleView()
        }
    }
}

#Preview {
    ScheduleView()
}

