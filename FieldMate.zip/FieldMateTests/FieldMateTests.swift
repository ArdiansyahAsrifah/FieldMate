//
//  FieldMateTests.swift
//  FieldMateTests
//
//  Created by Muhammad Ardiansyah Asrifah on 20/03/25.
//

import Testing
@testable import FieldMate

struct FieldMateTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
